# headreg:internal/grab_head —— 抓执行者头颅到共享中转槽，并读回 profile
# 入口：@s = 目标玩家
# 出口：storage headreg:data root.working_data = {name,id,properties}（现代形状）；
#       #found = 1 成功 / 0 失败
# 本文件是 legacy（1.20.2–1.20.4）专用变体：该区间没有 item components，
# fill_player_head 只能经 item_modifiers/fill_head.json 引用，profile 落在
# item.tag.SkullOwner（Id/Name/Properties.textures），故在此归一化成现代 shape，
# 让 classify / extract_ts / build_uuid 之后的链路完全不变。
data remove storage headreg:data root.working_data
execute in minecraft:overworld run item replace entity @e[type=minecraft:item_display,tag=headreg.display,limit=1] container.0 with minecraft:player_head 1
execute as @s in minecraft:overworld run item modify entity @e[type=minecraft:item_display,tag=headreg.display,limit=1] container.0 headreg:fill_head
execute store success score #found headreg.calc run data modify storage headreg:data root.working_data set from entity @e[type=minecraft:item_display,tag=headreg.display,limit=1] item.tag.SkullOwner
execute if score #found headreg.calc matches 1 run data modify storage headreg:data root.working_data.name set from storage headreg:data root.working_data.Name
execute if score #found headreg.calc matches 1 run data modify storage headreg:data root.working_data.id set from storage headreg:data root.working_data.Id
execute if data storage headreg:data root.working_data.Properties.textures[0].Value run data modify storage headreg:data root.working_data.properties set value [{name:"textures",value:""}]
execute if data storage headreg:data root.working_data.Properties.textures[0].Value run data modify storage headreg:data root.working_data.properties[0].value set from storage headreg:data root.working_data.Properties.textures[0].Value
data remove storage headreg:data root.working_data.Name
data remove storage headreg:data root.working_data.Id
data remove storage headreg:data root.working_data.Properties
