# 变更日志 · doom.headreg

> **口径**：namespace `headreg`（玩家上线档案：自动登记 / 正版判定 / 档案时间戳解码 / 会话时长与历史）。
> `pack_format` 94，`supported_formats` 48–94，并显式写出 `min_format` / `max_format`。
> 无依赖包；自断言 `headreg:test/run`（**37 个用例**）+ 只读自检 `headreg:api/audit`（7 项）。
> 判定**必须**读计分板 `#pass/#fail/#calls headreg.test`（套件用 tellraw 上报，不进服务端日志）。
>
> ✅ **2026-10-18 起 37/37 全绿**（clean-room 重测，含 3 个跨重启用例）。

---

## 2026-10-18 · v1.0.0 —— 首个公开版本

### 功能

- **自动登记**：玩家进服即登记，分配稳定数字编号，按编号分桶存 `storage headreg:data`。
- **正版判定**：读玩家档案里的 `properties.textures`，命中为 `1b`，否则 `0b`（离线档案）。
- **真时间戳**：mcfunction 内完成 base64 解码 → 定位 JSON 的 `timestamp` → 取 13 位毫秒 → 纯算术日历渲染成 `YYYY-MM-DD HH:MM:SS`。
- **会话统计**：登记次数、离开次数、上一段在线 tick、本次结束方式（`solo` / `personal` / `global`）。
- **历史会话**：最近 10 段，每段进出时刻与时长。
- **名字索引**：`headreg:index` 支撑按名字查，删档时自动回收。
- **玩家自助**：`/trigger headreg.qlist set 1`（名单）、`/trigger headreg.query set <编号>`（本人档案），无需 OP。
- **只读自检**：`api/audit` 7 项一致性检查，绿字一行或逐条红字 + 汇总。

### 本次修掉的两个真缺陷（clean-room 重测发现）

- **`api/audit` 对离线档案误报**：离线档案合法地没有 `last_leave_sec`，原本被判失败。改为只对正版档案要求该字段。
- **跨重启结算整体后移一个停机时长**：`gametime` 在停机期间不走、墙钟在走，用新锚点折算重启前的 `last_seen` 会整体偏移。改为 `load` 留档 `clock.prev` + `schedule 1t` 记 `clock.boot`，结算时按 `last_seen < boot` 选锚点，并加可信度守卫（`sec ≥ 1e9`、`tick ≥ 1`），不可信则回落当前锚点。

### 兼容性

- 实测通过：**1.21.11**
- 同代码段可用、未实测：1.21.0 – 1.21.10
- 1.20.5–1.20.6：需把 `function/` 目录改回 `functions/`（1.21 起才用单数）
- 1.20.4 及更早：不支持（无 item components、无字符串切片）

### 已知边界（首发即声明）

- 无法区分正常退出 / 掉线 / 被踢（`leave_game` 三者都是 +1）。
- 离开时刻由 `last_seen` 倒推，误差 1–4 秒；时长本身用 `play_time` 差值，精确。
- `premium=1b` 只证明"档案含皮肤数据"，不等于"已购买"，且签名不校验、可伪造。
- 纯离线服无墙钟锚点 ⇒ 不写日期、不写历史；只要有一个正版档案登录过即恢复。
- 历史上限 10 段；`dur_sec` 与两端差可能差 1 秒。

### 工程

- 三个离线静态门（`.github/tools/`）：泄漏扫描 + 顶层白名单 / 包体与函数引用闭包 / 发行物逐字节一致。
- 开发期沉淀的三条 1.21.11 宏约束（`$` 行必须含变量、`$` 行不能 `return`、含 `$(…)` 的行必须自带 `$`）已写进各函数注释。
